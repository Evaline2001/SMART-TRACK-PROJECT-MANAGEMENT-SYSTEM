# Client: React app

Run `npm install` then `npm start` in the client folder.